# Bug 修复

## 适用场景

- 功能模块运行异常
- 回调 / 事件未触发
- 流程卡住不动
- 进程崩溃 / 日志报错
- 接口调用无响应

---

## 排查流程

### 0. 读取设计 & 分析文档（必须先执行）

#### 0-A. 检查需求 / 设计文档

**在开始定位前**，先列出 `.evospec/output/design/` 下的可用文档：

```bash
ls .evospec/output/design/
```

若目录非空，根据 bug 现象按下表选择并**逐个读取**对应文档：

| 现象关键字 | 优先读取的文档 |
|-----------|---------------|
| 流程 / 阶段行为与预期不符 | `*-flow.md`、`*-design.md` |
| 接口 / 消息格式存疑 | `ARCHITECTURE.md`、`*-design.md` |
| 不确定功能预期行为 | `ARCHITECTURE.md`（全局概览） |

读取后，**判断 bug 现象是否与设计预期一致**：
- **不一致** → 记录为设计/实现偏差，**仍继续执行 0-B**，通过代码分析确认实际实现位置。
- **一致** → 继续执行 0-B 查代码实现。

> 若目录为空或文档不存在，跳过本步，直接进入 0-B。

#### 0-B. 读取代码分析文档

列出 `.evospec/output/code-analysis/` 下的可用文档：

```bash
ls .evospec/output/code-analysis/
```

若目录非空，根据 bug 现象按下表选择并**逐个读取**对应文档：

| 现象关键字 | 优先读取的文档 |
|-----------|---------------|
| 流程卡住、阶段失败 | `*-flow.md`、`init-flow.md`、`upgrade-flow.md` |
| 模块 / 回调未触发 | `plugin-system.md`、`core-modules.md` |
| 消息收发异常 | `message-flow.md` |
| 日志出现错误码 | `error-codes.md` |
| 不确定涉及哪个模块 | `core-modules.md`（全局概览） |
| 架构 / 初始化顺序 | `*-detail-design.md`、`init-flow.md` |

> 若目录为空或文档不存在，跳过本步，直接从步骤 1 开始。

读取完成后，**输出初步定位结论**（后续步骤基于此展开）：

```
涉及模块：<模块名>
可疑代码段：<文件路径> → <函数 / 类名>
定位依据：（引用文档中的关键描述或流程节点）
```

---

### 1. 确认现象

收集以下信息：
- 故障表现（日志关键字、错误码、卡住阶段）？
- 是必现还是偶现？
- 最近有哪些代码改动与此相关？

### 2. 日志定位

参考 `@references/project-info.md` 中的日志 TAG 定义，抓取可疑模块日志：

```bash
# 根据实际项目调整 TAG 过滤
adb logcat | grep -E "<module-tag-from-project-info>"
```

结合步骤 0 的初步定位，在可疑代码段中搜索关键调用路径。

### 3. 精确定位

基于步骤 0 的模块初定位，做针对性检查：
- 查看可疑函数的调用链（参考文档中的流程图 / 时序描述）
- 确认关键前置条件是否满足（初始化顺序、回调注入、配置项）
- grep 确认实际代码与文档描述是否一致，找出偏差点

### 4. 本地复现（如条件允许）

参考 `@references/us-build.md` 构建后，使用测试工具复现问题。

### 4.5 修复代码注释检查（R007 检查点）

修改或新增的每一行代码必须附中文注释，检查清单：

- [ ] 新增变量 / 成员 → 行尾注释说明用途
- [ ] 条件分支 → 注释说明判断原因
- [ ] 函数调用 → 注释说明调用目的
- [ ] 返回值 → 注释说明返回含义

```cpp
// ✅ 修复代码注释示例
speed_ = speed;                              // 保存最新车速，供 Presentation 层读取
if (!label) {                                // 控件不存在，布局文件可能未加载
    SLOG_ERROR("widget not found: speed_label"); // 打印控件名方便定位
    return;                                  // 提前退出，避免空指针崩溃
}
widget_set_text_utf8(label, std::to_string(speed_).c_str()); // 将车速转字符串写入控件
```

### 4.6 修复代码循环性能检查（R008 检查点）

当修复内容涉及定时器回调（含 `RET_REPEAT`）、`onUpdate`、PPS 轮询等循环函数时，检查修改后代码：

- [ ] 循环体内是否有 `widget_move`、`widget_set_value`、`widget_set_visible` 等 AWTK 接口被无条件调用
- [ ] 若有 → 添加 `last_xxx_` 成员缓存上次值，用 `if (new_val != last_xxx_)` 包裹后再调用

```cpp
// ❌ 修复前仍存在的隐患：每帧无条件调用
widget_move(needle_, x_, y_);

// ✅ 修复后：变化才调用
if (x_ != last_x_ || y_ != last_y_) {
    widget_move(needle_, x_, y_);          // 坐标变化时才移动，避免无效重绘
    last_x_ = x_;                          // 更新缓存值
    last_y_ = y_;
}
```

### 5. 修复后验证

重新编译并推板验证：
- 编译：`@references/us-build.md`
- 推板：`@references/us-board-deploy.md`

### 6. 生成 Bug 修复记录（必须）

验证通过后，在 `.evospec/output/bug-log/` 下生成记录文件。

**文件命名**：`YYYYMMDD-<ones-id>-<简短描述>.md`
例：`20260511-123456-初始化回调未注入导致消息丢失.md`

**记录模板**：

```markdown
# Bug 修复记录

- 日期：YYYY-MM-DD
- ONES ID：#XXXXXX
- 涉及模块：<模块名>

## 问题现象

（描述用户 / 测试发现的具体表现）

## 原因分析

（根本原因，引用定位到的代码段和文档依据）

## 修改点

| 文件 | 修改内容 |
|------|----------|
| `path/to/file.cpp` | 修改说明 |

## 验证结果

（验证方式和结果）
```

生成记录文件后，进入 Git 提交：`@references/us-git-submit.md`
