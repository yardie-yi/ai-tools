# 首次配置与依赖安装

## 1. 先收集用户配置

配置路径：有 `XDG_CONFIG_HOME` 时使用其下的 `italent-meal-allowance/profile.json`；否则使用 `~/.config/italent-meal-allowance/profile.json`。`~` 表示当前用户主目录，不使用创建本技能者的绝对路径。

文件不存在、JSON 损坏、字段为空或缺少任意必填项，都视为配置尚未完成。首次询问示例：

> 首次使用需要你提供：①餐补工作簿链接，②iTalent 考勤入口链接，③预期员工姓名。请一次发给我。

本次请求已提供部分字段时，只询问其余字段。三项未齐全前停止，不打开考勤页、不读取餐补表，也不写入业务数据。完整姓名或链接不要从旧聊天和本技能的历史案例中补猜。

收到三项后，去除首尾空白；两个链接必须是完整的 HTTPS 地址，有主机名且不含 URL 用户名或密码。餐补链接应为飞书 `/sheets/` 或 `/wiki/` 资源；考勤入口应为用户提供的 iTalent 页面。无法识别或员工姓名为空时，说明具体问题并请求更正。URL 格式有效不代表当前账户拥有访问权限，后续仍需核对。

按以下字段保存用户实际输入：

| 字段 | 含义 |
| --- | --- |
| `workbook_url` | 餐补工作簿链接，保留用户明确指定的工作表参数 |
| `attendance_url` | iTalent 考勤入口链接 |
| `expected_employee` | 预期员工姓名 |

本机文件只保存这三项，不保存密码、Cookie、访问令牌或临时跳转会话参数。目录权限使用 `0700`，文件权限使用 `0600`；只在三项有效后写入完整 JSON。配置不放入技能目录，因此同步或更新技能不会带走个人配置。没有持久文件访问能力时明确说明限制，当次使用用户输入，不假装已经保存。

已有完整配置时直接复用；新任务覆盖值以本次要求为准。只有用户明确要求修改默认配置时，才持久更新已有配置。

## 2. 检查实际安装状态

配置完成后、读取业务数据前，检查当前可用技能清单和实际 `SKILL.md` 文件。Codex 常用安装位置为 `${CODEX_HOME:-$HOME/.codex}/skills`，也要识别 `~/.agents/skills` 或当前平台已列出的技能根目录。可读取的现有技能直接复用；不能仅因本轮清单未刷新就反复安装。只安装缺失项，不覆盖用户定制版本，不修改插件缓存或其他无关技能。

| 依赖 | 何时需要 |
| --- | --- |
| `lark-shared` | 所有飞书操作 |
| `lark-sheets` | 读写餐补电子表格 |
| `lark-wiki` | 餐补链接路径包含 `/wiki/` |
| `browser-harness` | 读取 iTalent 必需；技能和同名命令均需可用，其他浏览器工具不能替代 |

发现缺失依赖后，由 agent 使用当前平台的技能安装器或包管理器，自行确认可信的官方来源、执行安装并验证。不要给用户罗列安装链接，也不要把可以自行完成的安装交给用户手工执行。下文命令供 agent 直接运行；若命令已过时，由 agent 查询当前帮助和官方包元数据后调整，不编造安装来源。

## 3. 自动安装飞书技能

代理直接执行安装，不让用户手工搜索或复制命令。以下示例适用于 Codex；其他平台用 `npx --yes skills --help` 查明对应 agent 名称，替换 `--agent codex`，不能把技能装到错误平台目录。

<!-- 补齐本次真正缺少的技能；已安装项从 --skill 参数中删去。 -->
```bash
# 将缺失的飞书技能安装到当前用户的 Codex 技能目录。
npx --yes skills add larksuite/cli --skill lark-shared lark-sheets --global --agent codex --yes
```

<!-- 仅当工作簿使用 Wiki 链接，且 lark-wiki 尚未安装时执行。 -->
```bash
# 安装 Wiki 链接解析技能。
npx --yes skills add larksuite/cli --skill lark-wiki --global --agent codex --yes
```

命令失败时先保留错误。若 Codex 的 `skill-installer` 可用，可读取该技能后，使用其真实脚本路径从同一官方仓库按目录安装：

<!-- INSTALLER 指向实际发现的安装脚本，不把下方赋值当成固定机器路径。 -->
```bash
# 自动发现 Codex 自带安装器；运行前确认该文件确实存在。
INSTALLER="${CODEX_HOME:-$HOME/.codex}/skills/.system/skill-installer/scripts/install-skill-from-github.py"
# 仅保留仍未安装的目录；与上面的 npx 安装二选一。
python3 "$INSTALLER" --repo larksuite/cli --path skills/lark-shared skills/lark-sheets
```

需要 `lark-wiki` 时，同样使用 `--path skills/lark-wiki`。安装器或父目录不存在时，不执行猜测路径，改用上面的 `npx` 路径或报告真实阻塞。

技能安装与 CLI 程序安装是两件事。若 `command -v lark-cli` 未找到程序，从官方 npm 包安装后检查版本：

<!-- 已有 lark-cli 时跳过，不为本任务无条件升级。 -->
```bash
# 安装缺少的飞书 CLI，并确认命令可执行。
npm install --global @larksuite/cli
lark-cli --version
```

缺少 Node.js/npm 时，由 agent 使用适合本机的官方安装器或受信任包管理器补齐运行时；权限或网络阻止安装时说明缺失项和失败命令，不把安装链接交给用户代做。认证配置另按 `lark-shared` 处理，不能把安装成功等同于已登录、有权限，也不能自动扩大授权范围。

## 4. 自动安装浏览器技能

`browser-harness` 是本任务读取 iTalent 的强制依赖。分别检查实际技能文件能否读取，以及 `command -v browser-harness` 能否定位同名命令；缺哪项补哪项。宿主已有内置浏览器、其他插件或 `browser-use` 入口，都不能作为跳过 `browser-harness` 安装和实际调用的理由。

如果宿主没有本机终端或命令执行工具（例如仅提供聊天和内置网页浏览能力），则无法自行安装和执行该 CLI。明确报告缺少执行能力并停止考勤读取及写表，请用户换到能执行本机命令的 agent 环境；不能假装安装成功，也不能改用其他浏览器继续。

若 `browser-harness` 命令不存在，安装官方 Python 包：

<!-- 仅在缺少命令时执行；不覆盖已可用的版本。 -->
```bash
# 为本机用户安装缺少的浏览器工具。
uv tool install --python 3.12 browser-harness
```

缺少 `uv` 时，由 agent 执行 `python3 -m pip install --user uv` 安装其官方 PyPI 包。安装后重新定位实际可执行文件；不能通过重写 `HOME` 或 `CODEX_HOME` 解决 PATH 问题。

命令已存在但技能文件缺失时，生成用户级技能文件；输出先写临时文件，核对包含合法 frontmatter 和非空正文后，再放入尚不存在的目标位置，避免错误响应损坏技能文件：

<!-- 变量只表示技能安装位置，不改变 HOME、CODEX_HOME 或其他系统变量。 -->
```bash
# 定位缺失技能的目标目录；有现有文件时跳过本块。
skill_target="${CODEX_HOME:-$HOME/.codex}/skills/browser-harness"
mkdir -p "$skill_target"
# 将工具自身提供的技能说明写入临时文件，核对后再命名为 SKILL.md。
browser-harness skill > "$skill_target/SKILL.md.tmp"
```

读取 `SKILL.md.tmp` 确认成功后，再重命名为 `SKILL.md` 并加载。生成失败只清理本次临时文件，不清理用户已有技能。安装不自动同意浏览器权限、开启录制或创建付费云浏览器；这些步骤依实际工具要求和当前授权处理。

## 5. 安装后的验收与失败处理

1. 逐个确认需要的技能存在可读取的 `SKILL.md`，并可解析 `name`、`description`；所引用的本地参考文件也要能读取。
2. 读取新安装技能及所需参考文档，再执行后续操作。当前技能清单可能下一轮才刷新，文件已安装时按实际路径读取，不能在同一轮重复安装。
3. 检查 `lark-cli --version`、`browser-harness --version` 和对应帮助是否能正常返回；随后读取浏览器技能，用 `browser-harness` 实际连接 Chrome，并核对 iTalent 页面、登录员工和考勤月份。版本命令成功不证明连接、考勤读取或业务访问成功。
4. 一次主安装失败，可在查明原因后换用上述同源备用路径一次；遇到相同阻塞就停止，返回缺失技能、已尝试的安装方式、已执行命令和实际错误，以及确实需要用户处理的权限或认证事项，不要求用户打开安装链接手动安装。未确认依赖可用前，不执行餐补表写入。
