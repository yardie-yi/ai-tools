# Project Agent Instructions

本项目使用 `.agent/` 下的 **Graph + Loop + Multi-Agent + Skill 协议**，并使用与 `.agent/` 同级的 `.evospec/` 保存项目参数、规则、输入和输出。

## 启动规则

处理非简单任务前，必须依次读取：

1. `.agent/project.yaml`
2. `.agent/router.yaml`
3. Router 选中的 `.agent/graphs/*.graph.md`
4. `.agent/skills/registry.yaml`
5. 当前 Graph 绑定的 `.agent/skills/<skill>/SKILL.md` 与最小必要 reference
6. registry 为选中 Skill 声明的 `project_config`；默认 model-skill 使用 `.evospec/module.config.yaml`
7. registry 为选中 Skill 声明的 `rules_index` 与当前阶段启用的规则文件
8. Graph 引用的 `.agent/nodes/*.md`
9. Graph 引用的 `.agent/loops/*.md`
10. 当前 `.agent/runs/*.json`；若不存在且任务复杂，创建一个 run state

简单解释、单文件查找或无需执行动作的问题可使用 `qa` Graph，不必创建 run state。即使是简单任务，也不得把 `.evospec` 中的占位符当成真实项目事实。

## Graph、Skill 与配置的职责

- **Graph Router**：选择宏观任务路线、权限和停止条件。
- **Graph / Node / Loop**：控制阶段顺序、迭代、验证、审查和 fresh Agent 路由。
- **Skill Registry**：将 Graph 或辅助任务绑定到稳定的 Skill reference。
- **Registered Skills**：`.agent/skills/` 中的可复用阶段流程；`model-skill` 是当前默认 Skill。
- **Skill project_config**：registry 声明的项目参数来源；默认 model-skill 使用 `.evospec/module.config.yaml`。
- **Skill rules_index**：registry 声明的项目约束入口；默认使用 `.evospec/rules/INDEX.md`。

优先级：Graph 的权限和质量门禁不能被 Skill 覆盖；Skill 不能凭空补全 `.evospec` 缺失值；确定性验证不能被 Worker 自述覆盖。

## 角色

- **Coordinator**：主线程。选 Graph、选择 Skill route、维护状态、调度 Agent、合并结果、决定路由。
- **Explorer**：只读搜索代码、文档、测试、构建配置和 `.evospec` 证据。
- **Implementer**：按已确认计划实施最小改动。
- **Debugger**：先定位 root cause，再实施最小修复。
- **Verifier**：运行构建、测试、静态检查、复现和安全 dry-run；不修改源代码。
- **Reviewer**：独立、只读、fresh context；输出结构化 Verdict。

Skill 自己的 grader 只评估路由、配置、规则和输出契约，不能代替代码 Reviewer 或 Verifier。

## 强制执行顺序

所有非简单任务的节点内部遵循：

```text
Observe → Decide → Act → Verify → Update State → Route
```

代码发生非平凡变更时，完成条件至少包括：

1. 需求或任务覆盖可追踪。
2. 构建通过，或明确标记环境阻塞。
3. 相关测试通过，或明确标记未验证风险。
4. 独立 Reviewer 给出 `PASS`；否则按路由规则处理。
5. 输出 changed files、验证证据和剩余风险。

## Skill 执行规则

1. 只加载当前 Graph/route 需要的 reference，不一次性读取整个 Skill。
2. 执行前检查 registry 声明的 `project_config` 及 unresolved markers；未声明配置的 Skill 不得被强行绑定到 module.config。
3. 当前阶段只应用 registry 声明的 `rules_index` 中启用且 `applies-to` 匹配的规则。
4. `REQUIRED`、`PLACEHOLDER`、`TODO_CONFIG`、空命令或未确认目标不得作为真实命令执行。
5. 部署、push、目标端删除、停止进程、覆盖文件等高影响动作，必须配置完整且获得用户明确授权；默认先 dry-run。
6. Skill reference 中的阶段跳转仍需经过当前 Graph 的 Verifier、Reviewer 和停止条件。

新增 Skill 的配置、Graph 接入和平台薄适配器必须遵循 `docs/ADDING_SKILLS.md`。

## 正确性证据优先级

```text
确定性执行结果 > 明确需求/接口契约 > 可复现行为 > 独立 Reviewer > Worker 自述
```

Worker 的“我认为完成了”不能覆盖失败的 build/test，也不能替代独立审查。

## Reviewer Verdict

只允许：

- `PASS`
- `PASS_WITH_RISK`
- `FAIL_LOCAL`
- `FAIL_STRUCTURAL`
- `NEED_USER_DECISION`
- `BLOCKED_ENVIRONMENT`

详细字段见 `.agent/verdict-schema.yaml`。

## 刷新新 Agent

满足任一条件时，Coordinator 应启动 fresh Agent，而不是让原 Agent 无限重试：

- 达到该 Loop 的重试上限。
- 相同错误签名连续出现 2 次。
- 连续 2 轮没有可测量进展。
- Reviewer 判断为 `FAIL_STRUCTURAL`。
- 修改范围持续扩大但验证结果没有改善。
- Agent 无法清晰解释 root cause 或反复改变核心假设。
- 上下文被大量日志和失败尝试污染。

Fresh Agent 必须使用 `.agent/prompts/fresh-agent-handoff.md` 的干净交接包，不能直接继承旧 Agent 的全部长对话。

## 安全与范围

- `qa`、`requirement`、`review` Graph 默认为只读。
- 不做无关重构。
- 不通过注释功能、删除行为或削弱测试绕过失败。
- 不执行发布、push、部署、删除大范围文件、修改凭证等高影响动作，除非用户明确授权。
- 专用硬件、服务器、密钥、供应商 SDK 等信息缺失时，记录 blocker；只有真正阻塞时才询问用户。
- `.evospec/scripts/deploy_from_config.py` 会执行配置中的 shell 命令；非 dry-run 使用前必须检查渲染结果和目标。

## 最终输出

复杂任务最终必须报告：

1. Selected Graph 与选择理由
2. Selected Skill / route、加载的 reference 和规则
3. 最终 Graph Node / Loop iteration
4. 需求和实现摘要
5. Changed files
6. Build/Test/Lint/复现/dry-run 结果
7. Reviewer Verdict
8. Fresh Agent 是否发生及原因
9. Remaining risks / blockers / unresolved configuration
