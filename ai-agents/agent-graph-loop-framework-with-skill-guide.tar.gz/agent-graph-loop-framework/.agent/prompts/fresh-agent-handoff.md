# Fresh Agent Handoff

## Identity

- Previous agent role/id:
- New agent role/id:
- Refresh trigger:

## Task Contract

- Goal:
- Selected Graph:
- Current Node:
- Definition of Done:
- Constraints:

## Skill Context

- Selected Skill:
- Selected Skill route:
- Loaded references:
- Loaded `.evospec` rules:
- Relevant configuration fields:
- Unresolved configuration:

## Current Repository State

- Changed files:
- Relevant files/symbols:
- Current branch/worktree:

## Deterministic Evidence

- Build command/result:
- Test command/result:
- Lint/static result:
- Reproduction/dry-run evidence:
- Normalized error signature:

## Previous Attempts — Summary Only

1. Action:
   Result:
2. Action:
   Result:

## Disproved or Unsafe Directions

-

## Open Questions

-

## Required First Action for Fresh Agent

Independently inspect the evidence and state whether the previous root-cause/implementation direction is accepted, rejected, or still unproven. Re-read the selected Skill reference and relevant `.evospec` configuration; do not repeat an old fix without new evidence.
