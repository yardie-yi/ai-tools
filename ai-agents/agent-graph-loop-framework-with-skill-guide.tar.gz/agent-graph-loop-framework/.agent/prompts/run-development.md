# Development Graph Prompt

请按项目里的 Graph + Loop + Skill 协议执行。

读取：

- `AGENTS.md`
- `.agent/project.yaml`
- `.agent/router.yaml`
- `.agent/graphs/development.graph.md`
- `.agent/skills/registry.yaml`
- `.agent/skills/model-skill/SKILL.md`
- `us-feature-dev.md`；进入构建时读取 `us-build.md`
- `.evospec/module.config.yaml` 的相关配置节
- `.evospec/rules/INDEX.md` 和 feature-dev 启用规则
- Graph 引用的 nodes 和 loops
- 当前 run state；如无则创建

任务：`{{TASK}}`

执行要求：

1. 主线程作为 Coordinator。
2. Explorer 只读分析上下文、配置来源和影响。
3. 先完成需求契约与计划，再实施。
4. Implementer 每轮只完成一个计划任务。
5. Verifier 独立运行 build/test/lint。
6. Reviewer 使用 fresh context，只读审查 Skill 规则、需求和验证证据。
7. 达到 `.agent/refresh-policy.yaml` 条件时刷新 Agent。
8. 未满足 Definition of Done 不得声明 DONE。
9. 不执行部署、commit 或 push，除非用户另外明确授权。
