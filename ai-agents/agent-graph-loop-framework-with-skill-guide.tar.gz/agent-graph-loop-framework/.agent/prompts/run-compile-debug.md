# Compile Debug Prompt

请从 Compile Debug Graph 开始。

构建日志：`{{BUILD_LOG}}`

加载 `us-build.md`、按需 `env-setup.md` 和 `.evospec` 构建配置。先分类错误并定位 root cause，再做最小修复。最多按项目配置重试；相同签名连续两次时刷新 Debugger。不得猜测服务器、clean 命令或工具链，也不得删除功能或注释调用绕过错误。
