# Development Graph

**用途**：新增功能、实现模块、按需求生成代码框架。

```text
START
  → CONTEXT
  → REQUIREMENT_ANALYSIS
  → IMPACT_ANALYSIS
  → PLAN
  → OPTIONAL_PLAN_REVIEW
  → IMPLEMENT [Implementation Loop]
  → COMPILE [Compile Debug Loop]
      ├─ PASS → TEST
      └─ EXHAUSTED → REFRESH_DEBUGGER / BLOCKED
  → TEST [Test Debug Loop]
      ├─ PASS → VERIFY
      └─ EXHAUSTED → REFRESH_DEBUGGER / BLOCKED
  → VERIFY
  → REVIEW [Review Loop]
      ├─ PASS → DONE
      ├─ PASS_WITH_RISK → RISK_DECISION
      ├─ FAIL_LOCAL → IMPLEMENT
      ├─ FAIL_STRUCTURAL → PLAN + FRESH_IMPLEMENTER
      └─ NEED_USER_DECISION → USER
```

角色：

- Coordinator：主线程。
- Explorer：上下文和影响搜索。
- Implementer：按计划实施。
- Verifier：运行 `scripts/verify.sh` 或等价命令。
- Reviewer：fresh、只读。

强制门禁：

- 非平凡代码变更必须 build。
- 行为变更必须运行相关测试。
- Reviewer 不能由 Implementer 自己充当。
- 不能因环境缺失直接输出完整 `PASS`。

## Skill 绑定

- Entry：`.agent/skills/model-skill/SKILL.md`
- 主 Reference：`.agent/skills/model-skill/references/us-feature-dev.md`
- 构建 Reference：`.agent/skills/model-skill/references/us-build.md`
- 配置：`.evospec/module.config.yaml` 的 `architecture`、`development`、`build`、`artifacts`、`paths`
- 规则：feature-dev 阶段启用规则。Skill 的“进入构建”不能跳过本 Graph 的 Test、Verifier 和 Reviewer。
