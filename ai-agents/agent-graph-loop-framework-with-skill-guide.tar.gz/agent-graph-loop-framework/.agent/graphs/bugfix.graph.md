# Bugfix Graph

**用途**：问题单、运行时异常、错误行为、日志故障。

```text
START
  → CONTEXT
  → REPRODUCE_OR_TRACE
  → ROOT_CAUSE [Bugfix Loop]
  → ROOT_CAUSE_CHECK
      ├─ evidence sufficient → FIX_PLAN
      └─ weak/repeated hypothesis → FRESH_DEBUGGER
  → IMPLEMENT_FIX
  → COMPILE [Compile Debug Loop]
  → TARGET_TEST [Test Debug Loop]
  → REGRESSION_VERIFY
  → REVIEW
      ├─ PASS → DONE
      ├─ FAIL_LOCAL → IMPLEMENT_FIX
      ├─ FAIL_STRUCTURAL → ROOT_CAUSE + FRESH_DEBUGGER
      └─ NEED_USER_DECISION → USER
```

完成条件：

- 说明复现方式或静态追踪证据。
- 区分 symptom 与 root cause。
- 最小修复，且验证目标行为和回归风险。
- Reviewer 检查“测试是否只是适配错误实现”。

## Skill 绑定

- Entry：`.agent/skills/model-skill/SKILL.md`
- 主 Reference：`.agent/skills/model-skill/references/us-bug-fix.md`
- 调试 Reference：`.agent/skills/model-skill/references/debug-commands.md`
- 构建 Reference：`.agent/skills/model-skill/references/us-build.md`
- 配置：`.evospec/module.config.yaml` 的 `paths`、`architecture`、`debug`、`development`、`build`
- 规则：bug-fix 阶段启用规则。生成 Bug 记录不代表修复正确，仍需确定性回归和 Reviewer。
