# Refactor Graph

**用途**：明确要求行为保持不变的去重、拆分和结构调整。

```text
START
  → CONTEXT
  → BASELINE_VERIFY
      ├─ PASS → REFACTOR_PLAN
      └─ UNAVAILABLE → RISK_DECISION
  → IMPLEMENT_SMALL_STEP [Implementation Loop]
  → BUILD_AND_TEST
      ├─ PASS + more steps → IMPLEMENT_SMALL_STEP
      ├─ PASS + done → REVIEW
      └─ FAIL → REVERT_OR_DEBUG
  → REVIEW
  → DONE
```

每次迭代必须是可回滚的小步。无法建立 baseline 时，不得宣称行为完全保持不变。

## Skill 绑定

可复用 `.agent/skills/model-skill/references/us-feature-dev.md` 中的最小改动、规则检查和构建要求，但不得把重构误判为新功能，也不得跳过 baseline。
