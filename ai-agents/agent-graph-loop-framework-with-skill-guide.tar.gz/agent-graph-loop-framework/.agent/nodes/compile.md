# Node: COMPILE

- 使用 `.agent/project.yaml` 指定的稳定 wrapper，默认 `./scripts/build.sh`；真实构建策略、shell 和 artifact 必须与 `.evospec/module.config.yaml` 的 `build`/`artifacts` 一致。
- 保存完整日志到 `.agent/logs/`，主状态只保留关键错误和签名。
- 记录命令、exit code、目标、配置和时间。
- Build PASS 只证明构建门禁，不证明需求完整。
