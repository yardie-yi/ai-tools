# Node: VERIFY

Verifier 独立于 Implementer：

1. 检查工作区和 changed files。
2. 运行 lint/build/test/reproduction。
3. 对照 Definition of Done 和需求追踪矩阵。
4. 输出确定性证据，不修改源代码。
5. 将结果写入 run state 的 `verification`。

Verifier 的 PASS 不替代 Reviewer；Reviewer 的 PASS 也不替代 Verifier。
