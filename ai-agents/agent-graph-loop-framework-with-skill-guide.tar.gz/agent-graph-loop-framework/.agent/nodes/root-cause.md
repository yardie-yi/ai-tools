# Node: ROOT_CAUSE

Root cause 必须解释：

- 为什么会出现当前 symptom。
- 哪个具体条件、接口、状态或配置导致。
- 为什么建议修复点比症状点更合适。
- 哪个验证可以证伪该假设。

只描述“某行报错”不等于 root cause。
