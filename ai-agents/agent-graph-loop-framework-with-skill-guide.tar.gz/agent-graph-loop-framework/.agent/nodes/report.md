# Node: REPORT

最终报告固定包含：

- Selected Graph / reason
- Selected Skill / route
- Loaded references / enabled rules / unresolved configuration
- Task and Definition of Done
- Requirement/impact summary
- Plan and completed tasks
- Changed files
- Build/Test/Lint/Reproduction/Dry-run evidence
- Reviewer Verdict and findings
- Refresh history
- Remaining risks and blockers
- Suggested next action（仅在确有未完成依赖时）
