# Node: TEST

- 先运行与变更最相关的测试，再运行必要回归。
- 记录测试范围、命令、exit code 和失败用例。
- 对硬件相关任务区分 host test、SIL、HIL 和实车/设备验证。
- 无法运行关键测试时，记录原因和替代证据，Verdict 不得是无风险 PASS。
