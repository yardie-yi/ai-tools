# Node: REVIEW

Reviewer 输入：

- 用户任务和 Definition of Done
- 需求/接口契约
- 当前 diff 或 changed files
- Verifier 证据
- 必要源码和测试

Reviewer 不应接收 Implementer 的全部长推理，以降低锚定偏差。

输出严格遵循 `.agent/verdict-schema.yaml`。
