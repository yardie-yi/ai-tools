# Claude Code Project Instructions

本项目的权威流程定义位于：

- `AGENTS.md`
- `.agent/project.yaml`
- `.agent/router.yaml`
- `.agent/graphs/`
- `.agent/nodes/`
- `.agent/loops/`
- `.agent/skills/registry.yaml`
- `.agent/skills/`（当前默认包含 `model-skill`）
- `.evospec/module.config.yaml`
- `.evospec/rules/`

Claude Code 处理复杂任务时：

1. 主会话担任 Coordinator，或使用 `.claude/agents/coordinator.md` 作为主 Agent。
2. 先选 Graph，再从 registry 选择 Skill，加载最小必要 reference 及该 Skill 声明的 `.evospec` 配置/规则。
3. 将搜索、日志分析、实现、验证和审查分配给对应项目级 subagent。
4. Reviewer 必须使用独立上下文，且不能编辑文件。
5. Verifier 可以执行会生成构建产物的命令，但不能修改源代码。
6. 所有 Agent 使用 `.agent/state-template.json` 约定的状态字段，包括 `skill` 字段。
7. 达到刷新条件时，不继续恢复原 Agent；启动同角色 fresh Agent，并提供干净 handoff。
8. 部署、push 和目标端破坏性动作默认只做配置检查/dry-run，除非用户明确授权。

可直接调用项目 Skill：

```text
/graph-loop-runner <任务描述>
```

项目级 Stop Hook 默认为关闭状态。需要 Stop 门禁时，参考 `.claude/settings.stop-gate.example.json`，审阅后再合并到 `.claude/settings.json`。

新增 Claude Skill 时，业务实现必须保留在 `.agent/skills/<skill-id>/`；`.claude/skills/` 只放薄适配器。完整步骤见 `docs/ADDING_SKILLS.md`。
