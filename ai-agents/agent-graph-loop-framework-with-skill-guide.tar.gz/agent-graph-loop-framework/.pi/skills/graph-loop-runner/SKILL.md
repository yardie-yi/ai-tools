---
name: graph-loop-runner
description: Applies this repository's Graph Router, project Skill registry, .evospec configuration/rules, node loops, deterministic verification, independent review, and fresh-session policy to complex tasks.
---

Read `AGENTS.md` and `.agent/protocol.md`, classify the task with `.agent/router.yaml`, then execute the selected Graph.

Before executing a stage, read `.agent/skills/registry.yaml`, the selected central Skill under `.agent/skills/`, its registry-declared reference and project configuration, and enabled stage rules. Do not treat unresolved markers as real values. Deployment, push, target removal, process stop, and remote overwrite require explicit user authorization and should begin with dry-run.

Pi core should not be assumed to provide built-in subagents. Represent roles using bounded phases in the current session, separate `/fork` or `/clone` sessions, external terminal sessions, or an installed extension/package. A Reviewer that judges an Implementer's work must use a fresh context whenever practical.

Use `.agent/prompts/fresh-agent-handoff.md` when switching sessions.


Do not duplicate central Skill logic under `.pi/skills/`; Pi-specific Skills must be thin adapters. See `docs/ADDING_SKILLS.md`.
