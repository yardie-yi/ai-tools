请按项目 Graph + Loop + Skill 协议执行开发任务：$@

读取 AGENTS.md、.agent/project.yaml、.agent/router.yaml、.agent/graphs/development.graph.md、.agent/skills/registry.yaml、绑定的 model-skill references、相关 .evospec 配置/规则，以及引用的 nodes/loops。
当前 Pi session 作为 Coordinator。将 Explorer、Implementer、Verifier、Reviewer 工作拆成独立、有界阶段；需要真正 fresh context 时使用 /fork、/clone、独立 Pi session、tmux 或项目安装的多 Agent extension。
必须维护 run state，运行 build/test，并使用 fresh reviewer handoff。未经授权不部署、不 commit、不 push。
