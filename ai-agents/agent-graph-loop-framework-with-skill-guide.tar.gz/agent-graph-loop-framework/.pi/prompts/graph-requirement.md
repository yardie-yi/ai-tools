请按 Requirement Analysis Graph 只读执行：$@

加载 model-skill 的 us-requirements.md、相关 .evospec 配置和启用规则。输出需求契约、影响矩阵、实现方案、假设和风险。跨模块、安全关键或高歧义任务必须使用独立 fresh review session。
