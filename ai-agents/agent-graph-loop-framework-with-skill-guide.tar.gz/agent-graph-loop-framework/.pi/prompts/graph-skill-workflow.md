请按 .agent/graphs/skill-workflow.graph.md 执行 model-skill 辅助任务：$@

从 .agent/skills/registry.yaml 选择一个 auxiliary route，只加载对应 reference 和 .evospec 配置/规则。先 preflight。部署、push、目标端删除、停止进程和远端覆盖默认只做 dry-run，除非用户明确授权。
