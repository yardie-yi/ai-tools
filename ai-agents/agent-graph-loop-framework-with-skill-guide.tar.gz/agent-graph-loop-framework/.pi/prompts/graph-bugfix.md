请按 Bugfix Graph 执行并使用 model-skill：$@

加载 us-bug-fix.md、按需 debug-commands.md/us-build.md 和相关 .evospec 配置/规则。先复现或静态追踪，定位 root cause，再做最小修复。相同错误签名连续两次或无进展两轮时，创建 fresh debugger session，并使用 .agent/prompts/fresh-agent-handoff.md。
