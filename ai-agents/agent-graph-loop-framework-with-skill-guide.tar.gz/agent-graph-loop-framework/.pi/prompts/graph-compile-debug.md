请按 Compile Debug Graph 执行：$@

加载 us-build.md、按需 env-setup.md 和 .evospec 构建配置。先分类和定位 root cause，再做最小修复并重新构建。不得猜测工具链/clean 命令，不得注释功能或删除调用绕过失败。达到刷新条件时切换 fresh debugger session。
