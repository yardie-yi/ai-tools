请作为 fresh、read-only Reviewer，按 .agent/graphs/review.graph.md 和 .agent/verdict-schema.yaml 审查：$@

同时读取任务绑定的 Skill reference、启用的 .evospec rules 和 Verifier 证据。不要修改文件；给出文件、符号、证据、风险和推荐路由。
