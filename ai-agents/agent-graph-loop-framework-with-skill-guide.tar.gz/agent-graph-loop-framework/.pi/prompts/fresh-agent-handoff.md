读取 .agent/prompts/fresh-agent-handoff.md，并基于以下任务创建一个干净交接包：$@
不要复制旧 session 的全部对话，只保留事实、证据、尝试摘要、已否定方向、约束和完成条件。
