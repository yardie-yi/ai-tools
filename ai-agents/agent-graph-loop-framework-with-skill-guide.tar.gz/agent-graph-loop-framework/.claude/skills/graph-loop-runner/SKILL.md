---
name: graph-loop-runner
description: Runs complex project tasks through the repository's Graph Router, project Skill registry, .evospec configuration/rules, node loops, verifier, independent reviewer, and fresh-agent policy.
argument-hint: "<task description>"
---

Use this skill for non-trivial requirement analysis, feature development, bug fixing, compile/test debugging, refactoring, review, or registered project-Skill auxiliary workflows.

1. Read `AGENTS.md`, `.agent/project.yaml`, `.agent/router.yaml`, and `.agent/protocol.md`.
2. Classify `$ARGUMENTS` and select exactly one parent Graph.
3. Read `.agent/skills/registry.yaml`; select the Graph binding or auxiliary route from the registered Skill; do not assume every route belongs to model-skill.
4. Load only the selected reference, the selected Skill's registry-declared project configuration, and enabled stage rules.
5. Run Skill preflight; unresolved configuration blocks execution or limits it to safe dry-run.
6. Create or load a run state under `.agent/runs/`, including the `skill` section.
7. Execute the graph node by node; each node uses the referenced loop.
8. Delegate noisy or specialized work to project subagents.
9. Keep Verifier and Reviewer separate from Implementer.
10. Apply `.agent/refresh-policy.yaml` when retry/no-progress/structural conditions are met.
11. Require explicit user authorization for deploy, push, target removal, process stop, or remote overwrite.
12. Finish with `.agent/nodes/report.md` format.
