# 项目入口桥接（合并到项目根 CLAUDE.md）

开始本项目任务前，显式读取根 AGENTS.md、.agent/loop.md 和本次任务单，并按任务读取引用的角色 / Graph 文件。需要独立审查时使用 reviewer，向其提供准确源码身份、diff 与测试产物；它不能自行执行测试。
