# 可选原生适配器

本目录只提供片段，未安装、未在用户环境试运行。仅选实际使用的平台，核对当前版本后，将内容**合并**到项目对应路径；不要覆盖已有配置或重复 TOML 表。通用 `.agent/` 文件仍是提示约定，不会自动变成 subagent。

## Codex

将 `codex/.codex/agents/reviewer.toml` 合并到项目 `.codex/agents/reviewer.toml`；将配置片段合并到 `.codex/config.toml`。项目配置还受信任状态和运行环境约束。并发上限 2 是示例，不是性能或验收要求；它不自动建立 Graph。

角色设置 read-only，但父会话 / 运行时沙箱和策略可能覆盖角色默认值，不能承诺绝对隔离。实际检查有效权限；需要写测试产物时只用获准隔离目录，否则只审已有证据。

[Subagents](https://learn.chatgpt.com/docs/agent-configuration/subagents) · [配置参考](https://learn.chatgpt.com/docs/config-file/config-reference)

## Claude Code

将 `claude/.claude/agents/reviewer.md` 合并到项目 `.claude/agents/reviewer.md`，入口片段合并到**项目根** `CLAUDE.md`。此 reviewer 只给 Read / Glob / Grep，未给 Bash，故只审源码及提供的 diff / 测试产物，不能自行跑测试或 git diff；缺材料向协调者索取。

[官方 subagents 文档](https://code.claude.com/docs/en/sub-agents)

## Pi

先在任务中显式要求读取根 `AGENTS.md` 与引用文件。Pi 核心不内置 subagent；需另用相应扩展 / 包，不能把本包角色文件当作自动启用配置。本包不安装扩展。

[Pi 官方 README](https://github.com/earendil-works/pi/blob/main/packages/coding-agent/README.md)

原生字段按 2026-10-12 查阅文档整理；版本可能变化。最保守入口始终是显式要求读取文件，并确认工具确实读取。
